import federation from '@originjs/vite-plugin-federation';
import vue from '@vitejs/plugin-vue';
import { defineConfig } from 'vite';

export default defineConfig({
  define: { 'process.env.SOFIA_ENV': 'undefined' },
  plugins: [
    vue(),
    federation({
      name: 'optiflowStarter',
      filename: 'optiflowStarter.js',
      exposes: { './App': './src/App.vue' },
      shared: ['vue', 'pinia'],
    }),
  ],
  resolve: { dedupe: ['vue', 'pinia', 'vue-i18n'] },
  server: { host: '127.0.0.1', port: 3048, strictPort: true },
  experimental: { renderBuiltUrl: () => ({ relative: true }) },
  build: {
    target: 'esnext',
    minify: false,
    cssCodeSplit: false,
    rollupOptions: {
      output: {
        assetFileNames: 'assets/[name].[ext]',
        chunkFileNames: 'assets/[name].js',
        entryFileNames: 'assets/[name].js',
      },
    },
  },
});