import { ref, shallowRef } from 'vue';
import type { ShallowRef } from 'vue';
import { createWorkflowGateway } from '../services/workflowService';
import { createConnectedStudioDemo, createLocalStudioDemo, studioDemoTarget } from '../services/studioDemoService';
import type { LengthResult, StudioDemoGateway, StudioDownload } from '../services/studioDemoService';

type StepState<Result> = { status: 'idle' | 'running' | 'error' } | { status: 'success'; result: Result };

export function useStudioDemo(connected: boolean) {
  const threadId = ref<string>();
  const busy = ref(false);
  const length = shallowRef<StepState<LengthResult>>({ status: 'idle' });
  const file = shallowRef<StepState<string>>({ status: 'idle' });
  const download = shallowRef<StepState<StudioDownload>>({ status: 'idle' });
  const generation = shallowRef<StepState<string>>({ status: 'idle' });
  let gateway = connected ? undefined : createLocalStudioDemo();

  async function run<Result>(state: ShallowRef<StepState<Result>>,
    operation: (service: StudioDemoGateway, id: string) => Promise<Result>): Promise<void> {
    if (busy.value) return;
    busy.value = true;
    state.value = { status: 'running' };

    try {
      gateway ??= createConnectedStudioDemo(createWorkflowGateway(
        (await import('ai-utils-lib')).axiosInstanceMS, studioDemoTarget,
      ));
      threadId.value ??= await gateway.createThread();
      const result = await operation(gateway, threadId.value);
      state.value = { status: 'success', result };
    } catch {
      state.value = { status: 'error' };
    } finally {
      busy.value = false;
    }
  }

  function checkLength(text: string): Promise<void> {
    return run(length, (service, id) => service.checkLength(id, text));
  }

  async function prepareFile(content: string): Promise<void> {
    if (busy.value) return;
    download.value = { status: 'idle' };
    await run(file, (service, id) => service.prepareFile(id, content));
  }

  async function getFile(): Promise<void> {
    if (file.value.status !== 'success') return;
    const documentId = file.value.result;
    await run(download, (service, id) => service.getFile(id, documentId));
  }

  function generateText(question: string): Promise<void> {
    return run(generation, (service, id) => service.generateText(id, question));
  }

  return { threadId, busy, length, file, download, generation, checkLength, prepareFile, getFile, generateText };
}