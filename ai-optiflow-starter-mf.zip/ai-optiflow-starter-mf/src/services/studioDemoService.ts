import { isRecord } from './workflowService.ts';
import type { WorkflowGateway, WorkflowTarget } from './workflowService.ts';

export const studioDemoTarget: WorkflowTarget = {
  workflowCode: 'DEMO_STUDIO',
  workflowVersion: 1,
  title: 'Studio Demo',
};

export const MAX_CSV_BYTES = 10_000;

export type LengthResult = 'OK' | 'TOO_SHORT';

export interface StudioDownload {
  filename: string;
  href: string;
}

export interface StudioDemoGateway {
  createThread(): Promise<string>;
  checkLength(threadId: string, text: string): Promise<LengthResult>;
  prepareFile(threadId: string, content: string): Promise<string>;
  getFile(threadId: string, documentId: string): Promise<StudioDownload>;
  generateText(threadId: string, question: string): Promise<string>;
}

function isShortTextError(error: unknown): boolean {
  if (!isRecord(error) || !isRecord(error.response) || error.response.status !== 400) return false;
  const { data } = error.response;
  return isRecord(data) && data.code === 'BAD_REQUEST'
    && typeof data.description === 'string' && data.description.startsWith('TEXT_TOO_SHORT:');
}

export function createConnectedStudioDemo(gateway: WorkflowGateway): StudioDemoGateway {
  return {
    createThread: gateway.createThread,
    async checkLength(threadId, text) {
      try {
        const status = await gateway.execute(threadId, 'COUNT_CHARACTERS', [{ name: 'text', value: text }], 'status');
        if (status !== 'OK') throw new Error('Invalid length result');
        return status;
      } catch (error) {
        if (isShortTextError(error)) return 'TOO_SHORT';
        throw error;
      }
    },
    async prepareFile(threadId, content) {
      const savedFile = await gateway.execute(threadId, 'PREPARE_FILE', [{ name: 'content', value: content }], 'savedFile');
      if (!isRecord(savedFile) || typeof savedFile.encodedName !== 'string' || !savedFile.encodedName.trim()) {
        throw new Error('Invalid saved file reference');
      }
      return savedFile.encodedName;
    },
    async getFile(threadId, documentId) {
      const download = await gateway.execute(threadId, 'GET_FILE', [{ name: 'documentId', value: documentId }], 'download');
      if (!isRecord(download) || typeof download.filename !== 'string' || !download.filename.trim()
        || typeof download.presignedUrl !== 'string') {
        throw new Error('Invalid download');
      }
      const url = new URL(download.presignedUrl);
      if (url.protocol !== 'https:' || url.username || url.password) throw new Error('Invalid download URL');
      return { filename: download.filename, href: download.presignedUrl };
    },
    async generateText(threadId, question) {
      const response = await gateway.execute(threadId, 'GENERATE_TEXT', [{ name: 'question', value: question }], 'response', 120_000);
      if (typeof response !== 'string' || !response.trim()) throw new Error('Invalid generation result');
      return response;
    },
  };
}

export function createLocalStudioDemo(): StudioDemoGateway {
  const filename = 'sample-rates.csv';
  const documentId = 'document-demo-local';
  let savedContent: string | undefined;

  return {
    async createThread() {
      return 'thread-demo-local';
    },
    async checkLength(_threadId, text) {
      return Array.from(text).length < 5 ? 'TOO_SHORT' : 'OK';
    },
    async prepareFile(_threadId, content) {
      if (!content || new TextEncoder().encode(content).length > MAX_CSV_BYTES) throw new Error('Invalid CSV size');
      savedContent = content;
      return documentId;
    },
    async getFile(_threadId, requestedId) {
      if (documentId !== requestedId || savedContent === undefined) throw new Error('Missing local file');
      return { filename, href: `data:text/csv;charset=utf-8,${encodeURIComponent(savedContent)}` };
    },
    async generateText() {
      return 'Simulation locale : dans cet exemple fictif, le paiement intervient dans les 30 jours.';
    },
  };
}