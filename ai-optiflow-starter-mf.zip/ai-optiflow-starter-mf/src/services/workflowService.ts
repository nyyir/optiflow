export interface WorkflowTarget {
  workflowCode: string;
  workflowVersion: number;
  title: string;
}

export interface WorkflowInput {
  name: string;
  value: string;
}

interface SofiaClient {
  post(path: string, body: object, options?: { headers: Record<string, string>; timeout: number }):
    Promise<{ data: unknown }>;
}

export interface WorkflowGateway {
  createThread(): Promise<string>;
  execute(threadId: string, stepCode: string, inputs: WorkflowInput[], outputName: string, timeout?: number): Promise<unknown>;
}

export function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

export function createWorkflowGateway(client: SofiaClient, target: WorkflowTarget): WorkflowGateway {
  const { workflowCode, workflowVersion, title } = target;
  const workflowPath = `/aiWorkflowManagement/V1/workflows/${encodeURIComponent(workflowCode)}`
    + `/versions/${encodeURIComponent(String(workflowVersion))}`;

  return {
    async createThread() {
      const { data } = await client.post('/aiThreadManagement/V1/threads', { workflowCode, workflowVersion, title });
      if (!isRecord(data) || typeof data.id !== 'string' || !data.id.trim()) {
        throw new Error('Invalid thread response');
      }
      return data.id;
    },
    async execute(threadId, stepCode, inputs, outputName, timeout = 30_000) {
      const { data } = await client.post(`${workflowPath}/steps/${encodeURIComponent(stepCode)}/execute`,
        { inputs }, { headers: { 'Context-Thread-Id': threadId }, timeout });

      if (!isRecord(data) || data.error || data.isGuardrailViolation || !Array.isArray(data.outputs)
        || (data.threadId !== undefined && data.threadId !== threadId)) {
        throw new Error('Invalid workflow response');
      }
      const outputs: unknown[] = data.outputs;
      const output = outputs.find(entry => isRecord(entry) && entry.name === outputName);
      if (!isRecord(output) || output.type === 'OUTPUT_GUARDRAIL' || !('value' in output)) {
        throw new Error('Missing workflow output');
      }
      return output.value;
    },
  };
}