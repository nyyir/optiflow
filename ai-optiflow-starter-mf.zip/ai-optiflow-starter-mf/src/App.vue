<script setup lang="ts">
import 'ai-components-lib/studio.css';
import { Badge, Button, Label, Textarea } from 'ai-components-lib/studio';
import { computed, ref, useId, watch } from 'vue';
import { useStudioDemo } from './composables/useStudioDemo';
import messages from './locales/fr.json';
import { MAX_CSV_BYTES } from './services/studioDemoService';

const connected = import.meta.env.VITE_STUDIO_DEMO_MODE === 'sofia';
const { threadId, busy, length, file, download, generation, checkLength, prepareFile, getFile, generateText } =
  useStudioDemo(connected);
const text = ref('ABC');
const content = ref('plan,rate\nStandard,1.25\nPremium,1.50\n');
const question = ref(messages.exampleQuestion);
const id = useId();
const csvTooLong = computed(() => new TextEncoder().encode(content.value).length > MAX_CSV_BYTES);
const textTooShort = computed(() => length.value.status === 'success' && length.value.result === 'TOO_SHORT');

watch(text, () => { length.value = { status: 'idle' }; });
</script>

<template>
  <div class="studio-theme starter" lang="fr">
    <header class="topbar">
      <div class="shell flex flex-wrap items-center justify-between gap-3">
        <div class="flex flex-wrap items-center gap-3 text-sm">
          <strong>{{ messages.brand }}</strong>
          <span class="text-muted-foreground">{{ messages.starter }}</span>
        </div>
        <Badge variant="outline">{{ connected ? messages.connected : messages.local }}</Badge>
      </div>
    </header>

    <main class="shell workspace">
      <h1 class="text-3xl font-semibold">{{ messages.title }}</h1>

      <div class="steps">
        <section class="step" :aria-labelledby="`${id}-length`">
          <h2 :id="`${id}-length`" class="text-lg font-semibold">{{ messages.lengthTitle }}</h2>
          <form class="step-form" @submit.prevent="checkLength(text)">
            <Label :for="`${id}-text`">{{ messages.text }}</Label>
            <Textarea :id="`${id}-text`" v-model="text" :readonly="busy" required
              :aria-invalid="textTooShort || undefined" :aria-describedby="`${id}-length-result`" />
            <Button type="submit" :aria-disabled="busy">{{ messages.checkLength }}</Button>
          </form>
          <p v-if="length.status === 'error'" :id="`${id}-length-result`" role="alert" class="result text-destructive">
            {{ messages.error }}
          </p>
          <p v-else :id="`${id}-length-result`" role="status" class="result" :class="{ 'text-destructive': textTooShort }">
            {{ length.status === 'running' ? messages.running : length.status === 'idle' ? messages.lengthEmpty
              : textTooShort ? messages.tooShort : messages.lengthOk }}
          </p>
        </section>

        <section class="step" :aria-labelledby="`${id}-file`">
          <h2 :id="`${id}-file`" class="text-lg font-semibold">{{ messages.fileTitle }}</h2>
          <form class="step-form" @submit.prevent="!csvTooLong && prepareFile(content)">
            <Label :for="`${id}-content`">{{ messages.content }}</Label>
            <Textarea :id="`${id}-content`" v-model="content" :readonly="busy" required class="font-mono"
              :aria-invalid="csvTooLong || undefined" :aria-describedby="csvTooLong ? `${id}-csv-limit` : undefined" />
            <p v-if="csvTooLong" :id="`${id}-csv-limit`" role="status" class="result text-destructive">{{ messages.csvTooLong }}</p>
            <Button type="submit" :disabled="csvTooLong" :aria-disabled="busy || csvTooLong">{{ messages.prepareFile }}</Button>
          </form>
          <p v-if="file.status === 'error'" role="alert" class="result text-destructive">{{ messages.error }}</p>
          <p v-else role="status" class="result">
            <template v-if="file.status === 'success'">{{ messages.fileReference }} : <code>{{ file.result }}</code></template>
            <template v-else>{{ file.status === 'running' ? messages.running : messages.fileEmpty }}</template>
          </p>
          <div class="step-form">
            <Button type="button" variant="outline" :disabled="file.status !== 'success'"
              :aria-disabled="busy || file.status !== 'success'" @click="getFile()">{{ messages.getFile }}</Button>
            <p v-if="download.status === 'running'" role="status" class="result">{{ messages.running }}</p>
            <p v-if="download.status === 'error'" role="alert" class="result text-destructive">{{ messages.error }}</p>
            <p v-if="download.status === 'success'" role="status" class="result">
              <a class="underline underline-offset-4" :href="download.result.href"
                :download="connected ? undefined : download.result.filename"
                :target="connected ? '_blank' : undefined" rel="noopener noreferrer">
                {{ messages.download }} {{ download.result.filename }}
              </a>
            </p>
          </div>
        </section>

        <section class="step" :aria-labelledby="`${id}-generation`">
          <h2 :id="`${id}-generation`" class="text-lg font-semibold">{{ messages.generationTitle }}</h2>
          <form class="step-form" @submit.prevent="question.trim() && generateText(question)">
            <Label :for="`${id}-question`">{{ messages.question }}</Label>
            <Textarea :id="`${id}-question`" v-model="question" :readonly="busy" required />
            <Button type="submit" :disabled="!question.trim()" :aria-disabled="busy || !question.trim()">
              {{ messages.generate }}
            </Button>
          </form>
          <p v-if="generation.status === 'error'" role="alert" class="result text-destructive">{{ messages.error }}</p>
          <p v-else role="status" class="result whitespace-pre-wrap">
            {{ generation.status === 'success' ? generation.result : generation.status === 'running'
              ? messages.running : messages.generationEmpty }}
          </p>
        </section>
      </div>

      <p v-if="threadId" class="result text-muted-foreground" role="status">{{ messages.thread }} : <code>{{ threadId }}</code></p>
    </main>
  </div>
</template>

<style scoped>
.starter {
  min-width: 0;
  min-height: 100dvh;
  background: var(--background);
  color: var(--foreground);
  font-family: 'Figtree', sans-serif;
}

.topbar { border-bottom: 1px solid var(--border); padding-block: 0.875rem; }
.shell { max-width: 72rem; margin-inline: auto; padding-inline: 1rem; }
.workspace { display: grid; gap: 1.75rem; padding-block: 1.5rem 2rem; }
.steps { display: grid; gap: 1.75rem; }
.step { display: grid; align-content: start; min-width: 0; gap: 0.875rem; border-top: 1px solid var(--border); padding-top: 1rem; }
.step-form { display: grid; gap: 0.625rem; min-width: 0; }
.step-form :deep(textarea) { min-height: 6rem; resize: vertical; }
.step-form :deep(button) { width: fit-content; max-width: 100%; height: auto; min-height: 2.25rem; white-space: normal; }
.step-form :deep(button[aria-disabled='true']) { opacity: 0.5; }
.result { min-height: 1.25rem; font-size: 0.875rem; line-height: 1.25rem; overflow-wrap: anywhere; }

@media (min-width: 44rem) {
  .shell { padding-inline: 2rem; }
  .workspace { padding-block-start: 2.5rem; }
}

@media (min-width: 62rem) {
  .steps { grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 2rem; }
}
</style>