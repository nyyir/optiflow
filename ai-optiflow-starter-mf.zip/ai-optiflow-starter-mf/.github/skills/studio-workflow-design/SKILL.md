---
name: studio-workflow-design
description: "A utiliser pour concevoir, creer, modifier ou valider a la demande une definition JSON de workflow SofIA: versions, steps, actions, formats et branchements."
---

# Construire un workflow SofIA

1. Confirmer le format cible. Pour une creation via l'API Workflow Management, se referer a `CreateWorkflowDto` et a ses modeles imbriques de version, step et action (source ou OpenAPI autorise). Pour un import Builder, verifier le parseur cible. Ne pas supposer que l'export et la creation attendent le meme document.
2. Partir d'une definition fournie ou demander seulement les informations manquantes : `code`, `name`, `description`, `type`, `emoji`, `color`, versions et statuts ; pour chaque step, code, inputs nommes avec type et format, sortie et actions ; pour chaque action, contexte, variables et branches. Valider le chemin `workflows/<CODE>.json` et utiliser des donnees fictives.
3. Placer les steps dans `versions[].steps`, les actions et `nextActions` dans leur step. Verifier unicite, destinations et ordre des branches, formats des variables, dependances entre actions et nom de sortie. Entre deux steps, prevoir une transmission explicite. Ne pas inventer de modele, prompt, version, droit ou service.
4. Utiliser [DEMO_STUDIO](../../../workflows/DEMO_STUDIO.json) comme exemple de branchement, fichier et generation independante, ou [DEMO_STUDIO_HELLO](../../../workflows/DEMO_STUDIO_HELLO.json) pour une transformation simple. Pour une exception, verifier sa forme HTTP ; pour un document, verifier la reference et le cycle de vie ; pour une generation, verifier le prompt et ses variables dans le catalogue cible.
5. Valider le JSON, les champs/alias du schema (y compris les champs ignores par le parseur) et le graphe. Lorsqu'un front le consomme, tester les entrees, les sorties et les chemins d'erreur avec des fixtures. Indiquer les prerequis d'execution, sans importer, activer ni publier le workflow depuis l'agent.