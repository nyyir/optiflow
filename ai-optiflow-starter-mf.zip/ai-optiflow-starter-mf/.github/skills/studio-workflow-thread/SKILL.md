---
name: studio-workflow-thread
description: "A utiliser pour appeler un workflow versionne dans Studio: session Thread, inputs et outputs nommes, fichiers, generation, simulation locale et erreurs de service."
---

# Appeler Thread et Workflow

1. Lire la definition du workflow dans `workflows/` ou le contrat du producteur. Noter le code, la version, les steps, les noms et formats, les droits et les prerequis de service. Ne pas deduire un contrat du seul libelle Builder ni d'une fixture quand la version differe.
2. Reutiliser le [transport](../../../src/services/workflowService.ts) avec `axiosInstanceMS` dans l'hote. Creer le thread au premier appel (`workflowCode`, `workflowVersion`, `title`), le memoriser dans le composable et envoyer `Context-Thread-Id` sur l'execution explicite. Reutiliser le thread seulement pour le meme contexte.
3. Envoyer `inputs: [{name, value}]` et valider la sortie par `outputs[].name`. Distinguer erreurs HTTP, rejet metier, guardrail et reponse invalide ; afficher un message localise sans recopier la reponse brute.
4. `nextActions` ne relie que des actions dans un step. Pour deux steps, le front transmet les donnees explicitement : dans [DEMO_STUDIO](../../../workflows/DEMO_STUDIO.json), `savedFile.encodedName` devient `documentId`. Document Management et Generation sont appeles par Workflow Management, pas par le navigateur. Ne pas journaliser ou persister le lien presigne.
5. Delimiter le contrat de chaque step dans un adaptateur, comme [studioDemoService.ts](../../../src/services/studioDemoService.ts). Fournir le meme parcours local sans HTTP et sans basculement automatique en cas d'erreur SofIA. Couvrir URL, payload, en-tete, sorties et erreurs avec des [tests locaux](../../../tests/studioDemoService.test.mjs), puis lancer `npm test`.