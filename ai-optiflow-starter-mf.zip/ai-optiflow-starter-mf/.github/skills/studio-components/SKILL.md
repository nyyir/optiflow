---
name: studio-components
description: "A utiliser pour creer ou modifier un ecran Vue Studio: composants, formulaires, etats, accessibilite, clavier et responsive."
---

# Composer un ecran Studio

1. Partir de la vue qui porte le parcours, par exemple [App.vue](../../../src/App.vue). Lire les [regles frontend](../../instructions/studio-frontend.instructions.md), puis les exports et declarations TypeScript de `ai-components-lib/studio` installe. Verifier props, slots et evenements avant de composer.
2. Associer `Label` a `Input`, `Textarea` ou `SelectTrigger`. Pour un choix, assembler `Select`, `SelectTrigger`, `SelectValue`, `SelectContent` et `SelectItem`. Pour une date, utiliser `Calendar` et garder la valeur de date independante du fuseau horaire. Utiliser `Button` pour une commande, un lien pour une navigation ou un telechargement.
3. Mapper les etats du composable vers la vue : vide, indisponible, attente, succes, erreur et reprise. Empecher les doubles soumissions sans perdre les saisies. Mettre les retours associes aux champs, conserver le focus et annoncer les resultats ou erreurs sans changer l'ordre de lecture.
4. Utiliser les tokens Studio et les messages de `src/locales/`. Verifier au clavier avec les fixtures locales, sur mobile et bureau, y compris les libelles, resultats et identifiants longs. Lancer `npm run type-check` pour les props et le template.