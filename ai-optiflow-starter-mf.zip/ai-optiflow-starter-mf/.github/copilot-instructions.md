# Consignes du starter Studio

- Ce depot est un point de depart autonome. Les exemples de `workflows/` ne sont pas des exigences metier. Ne jamais inventer un format, un droit ou une regle ; verifier le contrat du producteur ou demander sa confirmation.
- Travailler depuis le fichier qui porte le comportement et verifier le changement avec le controle local le plus cible. Conserver les dependances et le verrou sans demande explicite.
- Garder le mode local utilisable sans session ni requete aux services. Il doit etre identifiable et ne doit jamais masquer un echec du mode SofIA.
- Utiliser uniquement des fixtures synthetiques. Ne jamais demander, copier ni journaliser des donnees personnelles, cookies, jetons, secrets, URL signees ou reponses brutes de service. Ne pas modifier le catalogue ni publier. Un test SofIA reel releve de l'equipe dans un environnement autorise.
- Executer `npm run type-check` pour le typage Vue, `npm test` pour les contrats et la simulation, et verifier au navigateur le parcours modifie. Reserver `npm run build` aux changements qui risquent d'affecter l'integration du paquet. Signaler les verifications non executees.