---
description: "Regles locales pour modifier les vues Vue, les messages, l'etat reactif ou les services TypeScript du microfrontend Studio."
applyTo: "src/**/*.vue,src/**/*.ts,src/locales/**/*.json"
---

# Frontend Studio

- Composer avec les exports publics `ai-components-lib/studio` de la version installee. Conserver `studio.css`, `studio-theme` et les tokens Studio. Ne pas copier un composant shadcn ni melanger les styles Sofia et Studio.
- Garder l'affichage et les interactions dans les composants, les textes dans `src/locales/`, l'etat reactif dans `src/composables/`, les appels et le decodage dans `src/services/`.
- Conserver TypeScript strict sans `any` ni assertion non verifiee. Valider les reponses depuis `unknown` au point d'entree HTTP. Representer explicitement l'attente, le succes et l'erreur.
- Utiliser des labels associes, des boutons et liens semantiques, des retours non exclusivement colores et un ordre de focus coherent. Verifier l'attente, la reprise apres erreur, le clavier et l'absence de debordement dans le parcours modifie.
- Utiliser `axiosInstanceMS` uniquement avec l'hote authentifie. Pas de secret dans `VITE_*`, pas de nouveau client d'authentification, pas de requete en mode local.