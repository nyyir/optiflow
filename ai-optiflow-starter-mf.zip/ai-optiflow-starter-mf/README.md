# Optiflow · Starter Studio

Un kit Vue 3 / TypeScript pour démarrer un microfrontend Studio. La démo montre comment exécuter un workflow SofIA, produire et télécharger un fichier et appeler un LLM, sans règle métier Optiflow.

## 🚀 Démarrage

Prérequis : Node.js 24 et accès autorisé au registre npm d’entreprise indiqué par le verrou. Configurer cet accès via la procédure de votre équipe ; aucun identifiant n’est fourni.

Depuis la racine du dossier :

```bash
npm ci --ignore-scripts --no-audit
npm run dev
```

Ouvrir http://127.0.0.1:3048/. Le mode local ne contacte pas SofIA et ne requiert pas de compte. Le rechargement efface le thread et le CSV local. Arrêter Vite avec `Ctrl+C`.

## 🧭 Parcours de démo

1. **Vérifier la longueur** avec `ABC`, puis avec `Studio` : le premier texte est refusé, le second accepté. Les espaces comptent.
2. **Enregistrer le CSV**, puis **Obtenir le lien** et **Télécharger sample-rates.csv**. Le CSV contient le texte fourni ; la limite est de 10 000 octets UTF-8.
3. **Générer une réponse** à tout moment. En local, le texte est simulé et identifié comme tel ; aucun modèle n’est appelé.

## 🧩 Contrat et code

| Step de [DEMO_STUDIO v1](workflows/DEMO_STUDIO.json) | Entrée envoyée | Sortie ou rejet | Traitement connecté |
| --- | --- | --- | --- |
| `COUNT_CHARACTERS` | `text` | `status: OK` ou HTTP 400 `BAD_REQUEST` préfixé `TEXT_TOO_SHORT:` dans `description` | Transformation Python et branche conditionnelle |
| `PREPARE_FILE` | `content` | `savedFile.encodedName` | Création CSV et dépôt dans Document Management |
| `GET_FILE` | `documentId` = `savedFile.encodedName` | `download.filename`, `download.presignedUrl` | Lecture dans Document Management et lien temporaire |
| `GENERATE_TEXT` | `question` | `response` | Generation avec le prompt configuré dans le workflow |

Le [transport](src/services/workflowService.ts) crée un thread avec `POST /aiThreadManagement/V1/threads` (`workflowCode`, `workflowVersion`, `title`), puis appelle `POST /aiWorkflowManagement/V1/workflows/{workflowCode}/versions/{version}/steps/{stepCode}/execute` avec `Context-Thread-Id` et `inputs: [{name, value}]`. Chaque exécution lit la sortie nommée dans `outputs[]`. Le front n’appelle directement ni Document Management ni Generation.

L’[adaptateur de démo](src/services/studioDemoService.ts) valide les sorties de chaque step, conserve la référence utile et fournit le mode local en mémoire. Le [composable](src/composables/useStudioDemo.ts) réutilise le thread créé au premier clic et gère les états de l’[écran Studio](src/App.vue). [Hello Studio](workflows/DEMO_STUDIO_HELLO.json) reste un exemple de définition minimale, sans écran associé.

## 🔌 Mode connecté facultatif

1. Dans un Studio de test autorisé, importer [DEMO_STUDIO](workflows/DEMO_STUDIO.json) et rendre sa version `1` exécutable. Vérifier les droits Thread et Workflow, l’accès à Document Management ainsi que la disponibilité du prompt `GENERAL_ASSISTANT_HAIKU_5_5` version `1` et de ses variables dans l’environnement. Si la cible change, adapter `studioDemoTarget` et vérifier les contrats des steps.
2. Dans `.env.local`, utiliser `VITE_STUDIO_DEMO_MODE=sofia` et lancer `npm run build`. Le mode se règle avant le build, pas en passant un paramètre dans le navigateur. Ne mettre aucun secret dans `VITE_*` : ces variables sont côté client.
3. Publier le répertoire `dist` complet dans l’environnement de test et intégrer l’entrée `assets/optiflowStarter.js` (`./App`) selon le processus catalogue de l’équipe. Le Studio fournit la session et la gateway à `axiosInstanceMS`. Le serveur local n’est pas un serveur d’authentification.

Utiliser uniquement les données synthétiques de la démo. Le mode connecté ne bascule pas en local si un appel échoue. Si un lien a expiré, relancer **Obtenir le lien** pour le même document.

## 🤖 Agent VS Code

Ouvrir **ce dossier comme racine** dans VS Code et choisir [Studio Starter](.github/agents/studio-starter.agent.md) dans GitHub Copilot Chat. L’agent travaille sur le projet et lance des vérifications locales. Il s’appuie sur les [consignes du projet](.github/copilot-instructions.md), les [règles frontend](.github/instructions/studio-frontend.instructions.md) et trois skills portables : [composer les écrans](.github/skills/studio-components/SKILL.md), [intégrer Thread et Workflow](.github/skills/studio-workflow-thread/SKILL.md), [construire un workflow](.github/skills/studio-workflow-design/SKILL.md).

Exemple : « Branche cet autre step et ajoute son équivalent local, sans modifier la session SofIA. » Ne transmettre que des fixtures synthétiques. L’agent ne publie pas et ne teste pas contre un environnement réel.

## 🧪 Vérifications

```bash
npm run type-check
npm test
npm run build
```

Les tests vérifient le contrat de la fixture, les requêtes simulées et le CSV local. Pour partager le kit, garder le code source, `workflows/`, le verrou et `.github`, sans `node_modules`, `dist` ni fichier d’environnement local.