import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { mock, test } from 'node:test';
import { createWorkflowGateway } from '../src/services/workflowService.ts';
import { createConnectedStudioDemo, createLocalStudioDemo, MAX_CSV_BYTES, studioDemoTarget } from '../src/services/studioDemoService.ts';

const threadId = 'thread-test';
const content = 'plan,rate\nStandard,1.25\n';
const download = { filename: 'sample-rates.csv', presignedUrl: 'https://storage.example.test/sample-rates.csv?fixture=1' };
const output = (name, value) => ({ data: { threadId, outputs: [{ name, value }] } });
const workflow = JSON.parse(readFileSync(new URL('../workflows/DEMO_STUDIO.json', import.meta.url), 'utf8'));
const [version] = workflow.versions;
const pathFor = step => `/aiWorkflowManagement/V1/workflows/${workflow.code}/versions/${version.version}/steps/${step}/execute`;
const connected = post => createConnectedStudioDemo(createWorkflowGateway({ post }, studioDemoTarget));

test('the bundled workflow defines the same target, named inputs and named outputs', () => {
  assert.deepEqual(studioDemoTarget, { workflowCode: workflow.code, workflowVersion: version.version, title: workflow.name });
  assert.deepEqual(version.steps.map(step => [step.code, step.inputs.map(input => input.name), step.output.name]), [
    ['COUNT_CHARACTERS', ['text'], 'status'],
    ['PREPARE_FILE', ['content'], 'savedFile'],
    ['GET_FILE', ['documentId'], 'download'],
    ['GENERATE_TEXT', ['question'], 'response'],
  ]);
  assert.equal(version.steps[1].actions[0].context.maxTextSize, MAX_CSV_BYTES);
});

test('calls the four steps with explicit DTOs and forwards the uploaded encodedName', async () => {
  const post = mock.fn(async path => {
    if (path.endsWith('/threads')) return { data: { id: threadId } };
    if (path === pathFor('COUNT_CHARACTERS')) return output('status', 'OK');
    if (path === pathFor('PREPARE_FILE')) return output('savedFile', { encodedName: 'csv-test', document_record: {} });
    if (path === pathFor('GET_FILE')) return output('download', download);
    if (path === pathFor('GENERATE_TEXT')) return output('response', 'Synthetic answer');
    throw new Error('Unexpected request');
  });
  const gateway = connected(post);
  const id = await gateway.createThread();
  assert.equal(await gateway.generateText(id, 'Payment terms?'), 'Synthetic answer');
  assert.equal(await gateway.checkLength(id, 'Studio'), 'OK');
  const reference = await gateway.prepareFile(id, content);
  assert.deepEqual(await gateway.getFile(id, reference), { filename: download.filename, href: download.presignedUrl });

  const request = (step, name, value, timeout = 30_000) => [pathFor(step),
    { inputs: [{ name, value }] }, { headers: { 'Context-Thread-Id': threadId }, timeout }];
  assert.deepEqual(post.mock.calls.map(call => call.arguments), [
    ['/aiThreadManagement/V1/threads', { workflowCode: 'DEMO_STUDIO', workflowVersion: 1, title: 'Studio Demo' }],
    request('GENERATE_TEXT', 'question', 'Payment terms?', 120_000),
    request('COUNT_CHARACTERS', 'text', 'Studio'),
    request('PREPARE_FILE', 'content', content),
    request('GET_FILE', 'documentId', 'csv-test'),
  ]);
});

test('rejects invalid thread, failed execution, mismatched thread and invalid output', async () => {
  const gatewayFor = data => connected(async () => ({ data }));
  await assert.rejects(gatewayFor({ id: ' ' }).createThread(), /Invalid thread/);
  const response = { name: 'response', value: 'Synthetic answer' };
  for (const data of [
    { error: { code: 'DEMO_ERROR' }, outputs: [response] },
    { isGuardrailViolation: true, outputs: [response] },
    { threadId: 'another-thread', outputs: [response] },
    { outputs: [] },
    { outputs: [{ ...response, value: 42 }] },
    { outputs: [{ ...response, type: 'OUTPUT_GUARDRAIL' }] },
  ]) {
    await assert.rejects(gatewayFor(data).generateText(threadId, 'Payment terms?'));
  }
});

test('only maps the workflow rejection, not other HTTP 400s, to TOO_SHORT', async () => {
  const reject = description => connected(async () => {
    throw { response: { status: 400, data: { code: 'BAD_REQUEST', description } } };
  });
  assert.equal(await reject('TEXT_TOO_SHORT: Enter at least 5 characters.').checkLength(threadId, 'abc'), 'TOO_SHORT');
  await assert.rejects(reject('Other error').checkLength(threadId, 'abc'));
});

test('rejects invalid file references, missing links and unsafe download schemes', async () => {
  await assert.rejects(connected(async () => output('savedFile', { id: 'not-an-encoded-name' }))
    .prepareFile(threadId, content), /Invalid saved file reference/);
  for (const presignedUrl of [null, '/file.csv', 'javascript:alert(1)', 'https://user@storage.example.test/file.csv']) {
    await assert.rejects(connected(async () => output('download', { ...download, presignedUrl }))
      .getFile(threadId, 'csv-test'));
  }
});

test('local mode simulates Python length, isolates file state and returns a real synthetic CSV', async () => {
  const gateway = createLocalStudioDemo();
  const id = await gateway.createThread();
  assert.equal(await gateway.checkLength(id, '🧪 ab'), 'TOO_SHORT');
  assert.equal(await gateway.checkLength(id, '🧪 abc'), 'OK');
  assert.match(await gateway.generateText(id, 'Payment terms?'), /^Simulation locale/);
  await assert.rejects(gateway.prepareFile(id, 'é'.repeat(5001)), /Invalid CSV size/);
  const reference = await gateway.prepareFile(id, content);
  const localDownload = await gateway.getFile(id, reference);
  assert.equal(localDownload.filename, 'sample-rates.csv');
  assert.equal(await (await fetch(localDownload.href)).text(), content);
  await assert.rejects(createLocalStudioDemo().getFile(id, reference), /Missing local file/);
});