import assert from 'node:assert/strict';
import { mock, test } from 'node:test';

const get = mock.fn();
mock.module('ai-utils-lib', { exports: { axiosInstanceMS: { get } } });
const { fetchWorkflowVersions } = await import('../src/services/workflowService.ts');

test('reads and validates workflow versions', async () => {
  get.mock.mockImplementation(async () => ({ data: [
    { version: 1, status: 'Draft' },
    { version: 2, status: 'Testing' },
    { version: 3, status: 'Ready' },
    { version: 4, status: 'Deprecated' },
  ] }));
  const versions = await fetchWorkflowVersions('MY WORKFLOW');
  assert.deepEqual(versions.map(version => version.status), ['Draft', 'Testing', 'Ready', 'Deprecated']);
  assert.equal(get.mock.calls.at(-1).arguments[0], '/aiWorkflowManagement/V1/workflows/MY%20WORKFLOW/versions');
});

test('rejects empty codes and malformed responses', async () => {
  const previousCalls = get.mock.callCount();
  await assert.rejects(fetchWorkflowVersions('  '), /workflow code/);
  assert.equal(get.mock.callCount(), previousCalls);
  for (const data of [null, {}, [{ version: '1', status: 'Ready' }], [{ version: 1, status: 'Archived' }]]) {
    get.mock.mockImplementation(async () => ({ data }));
    await assert.rejects(fetchWorkflowVersions('EXAMPLE'), /Invalid workflow version/);
  }
});

test('propagates transport errors', async () => {
  const failure = new Error('Network unavailable');
  get.mock.mockImplementation(async () => { throw failure; });
  await assert.rejects(fetchWorkflowVersions('EXAMPLE'), error => error === failure);
});