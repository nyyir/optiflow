import { defineConfig } from 'vite';
import vue from '@vitejs/plugin-vue';
import federation from '@originjs/vite-plugin-federation';

export default defineConfig(({ command }) => ({
  define: command === 'serve' ? { 'process.env.SOFIA_ENV': 'undefined' } : {},
  optimizeDeps: command === 'serve' ? { esbuildOptions: { define: { 'process.env.SOFIA_ENV': 'undefined' } } } : {},
  plugins: [
    vue(),
    federation({
      name: 'optiflow',
      filename: 'optiflow.js',
      exposes: { './App': './src/App.vue' },
      shared: ['vue', 'pinia'],
    }),
  ],
  resolve: { dedupe: ['vue', 'pinia', 'vue-i18n'] },
  server: { port: 3037, strictPort: true, cors: true },
  preview: { port: 3037, strictPort: true, cors: true },
  experimental: { renderBuiltUrl: () => ({ relative: true }) },
  build: {
    target: 'esnext',
    minify: false,
    cssCodeSplit: false,
    rollupOptions: {
      output: {
        assetFileNames: 'assets/[name].[ext]',
        chunkFileNames: 'assets/[name].js',
        entryFileNames: 'assets/[name].js',
      },
    },
  },
}));