import { i18n as componentsI18n } from 'ai-components-lib';
import { buildMicroFrontendI18nState, type ComponentLibraryI18nAdapter, type LocaleModule } from 'ai-utils-lib';
import { createI18n } from 'vue-i18n';

const localeModules = import.meta.glob<LocaleModule>('./locales/**/*.json', { eager: true });

type MessageValue = string | MessageValue[] | MessageObject;
type MessageObject = { [key: string]: MessageValue };

function isMessageValue(value: unknown): value is MessageValue {
  if (typeof value === 'string') return true;
  if (Array.isArray(value)) return value.every(isMessageValue);
  return value !== null && typeof value === 'object' && Object.values(value).every(isMessageValue);
}

export function createTemplateI18n() {
  const { messages, initialLocale, fallbackLocale, subscribeLanguage } = buildMicroFrontendI18nState({
    localeModules,
    componentI18n: componentsI18n.global as unknown as ComponentLibraryI18nAdapter,
    fallbackLocale: 'fr',
  });

  const validatedMessages: Record<string, MessageObject> = {};
  for (const [locale, resource] of Object.entries(messages)) {
    if (!isMessageValue(resource)) throw new Error(`Invalid translations for locale ${locale}`);
    validatedMessages[locale] = resource;
  }

  const i18n = createI18n({
    legacy: false,
    locale: initialLocale,
    fallbackLocale,
    messages: validatedMessages,
    globalInjection: true,
  });

  return { i18n, subscribeLanguage };
}