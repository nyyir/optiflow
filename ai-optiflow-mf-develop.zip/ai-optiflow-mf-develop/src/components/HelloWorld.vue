<script setup lang="ts">
import { useI18n } from 'vue-i18n';

const { t } = useI18n({ useScope: 'global' });
</script>

<template>
  <h1>{{ t('frontTemplate.hello') }}</h1>
</template>

<style scoped>
h1 {
  margin: 0;
  font-size: 1.5rem;
  line-height: 1.3;
  overflow-wrap: anywhere;
}
</style>