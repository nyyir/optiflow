<script setup lang="ts">
import 'ai-components-lib/studio.css';
import { getCurrentInstance, onUnmounted, provide } from 'vue';
import { I18nInjectionKey } from 'vue-i18n';
import HelloWorld from './components/HelloWorld.vue';
import { createTemplateI18n } from './i18n';

const { i18n, subscribeLanguage } = createTemplateI18n();

const host = getCurrentInstance()?.appContext.app;
const hostI18nSymbol: unknown = host ? Reflect.get(host, '__VUE_I18N_SYMBOL__') : undefined;
if (typeof hostI18nSymbol === 'symbol') provide(hostI18nSymbol, i18n);
provide(I18nInjectionKey, i18n);

const unsubscribe = subscribeLanguage(language => {
  i18n.global.locale.value = language;
});
onUnmounted(unsubscribe);

const { locale } = i18n.global;
</script>

<template>
  <main class="studio-theme template-app" :lang="locale">
    <HelloWorld />
  </main>
</template>

<style scoped>
.template-app {
  box-sizing: border-box;
  min-width: 0;
  min-height: 100%;
  padding: 2rem;
  background: var(--background);
  color: var(--foreground);
  font-family: 'Figtree', sans-serif;
}

</style>