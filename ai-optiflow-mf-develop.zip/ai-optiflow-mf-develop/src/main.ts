import { createApp } from 'vue';
import { createPinia } from 'pinia';
import App from './App.vue';
import { createTemplateI18n } from './i18n';

createApp(App).use(createPinia()).use(createTemplateI18n().i18n).mount('#app');