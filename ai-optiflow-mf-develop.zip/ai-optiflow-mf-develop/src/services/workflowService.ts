import { axiosInstanceMS } from 'ai-utils-lib';

export interface WorkflowVersionSummary {
  version: number;
  status: 'Draft' | 'Testing' | 'Ready' | 'Deprecated';
}

function parseVersion(value: unknown): WorkflowVersionSummary {
  if (typeof value !== 'object' || value === null || !('version' in value) || !('status' in value)) {
    throw new Error('Invalid workflow version response');
  }
  if (typeof value.version !== 'number' || !Number.isInteger(value.version)) {
    throw new Error('Invalid workflow version response');
  }
  if (value.status !== 'Draft' && value.status !== 'Testing' && value.status !== 'Ready' && value.status !== 'Deprecated') {
    throw new Error('Invalid workflow version response');
  }
  return { version: value.version, status: value.status };
}

export async function fetchWorkflowVersions(workflowCode: string): Promise<WorkflowVersionSummary[]> {
  if (!workflowCode.trim()) throw new Error('A workflow code is required');
  const { data } = await axiosInstanceMS.get<unknown>(
    `/aiWorkflowManagement/V1/workflows/${encodeURIComponent(workflowCode)}/versions`,
  );
  if (!Array.isArray(data)) throw new Error('Invalid workflow versions response');
  return data.map(parseVersion);
}