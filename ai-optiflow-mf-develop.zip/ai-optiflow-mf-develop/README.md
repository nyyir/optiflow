# ai-optiflow-mf

Socle Vue 3 et TypeScript pour créer un microfrontend intégré au Studio. Il affiche uniquement un message de bienvenue et fournit un exemple d'appel à un microservice, sans requête automatique.

## 🚀 Installation et démarrage

Prérequis : Node.js 24, npm et accès au registre npm de l'entreprise pour les bibliothèques CACF. Depuis ce répertoire :

```bash
npm ci --ignore-scripts
npm run dev -- --host 127.0.0.1
```

Ouvrir http://127.0.0.1:3037/ : le message de bienvenue s'affiche. Arrêter le serveur avec `Ctrl+C`. Le port est strict ; s'il est occupé, utiliser `npm run dev -- --host 127.0.0.1 --port 3039` et adapter les URLs locales. Le mode autonome ne lance aucun appel API et ne crée pas de session ; pour appeler un MS protégé, suivre la section [Authentification en local](#-authentification-en-local).

Pour tester le build :

```bash
npm run build
npm run preview -- --host 127.0.0.1 --port 3038
```

La prévisualisation est une page autonome. Pour utiliser le remote depuis un autre serveur, publier le répertoire `dist` complet, pas uniquement son fichier d'entrée.

## 🧭 Utilisation

1. Installer les dépendances et lancer le projet comme indiqué ci-dessus.
2. Conserver le nom de fédération unique défini dans [vite.config.ts](vite.config.ts) et l'exposition `./App` ; adapter les ports si nécessaire.
3. Remplacer [HelloWorld.vue](src/components/HelloWorld.vue) ou le contenu de [App.vue](src/App.vue), puis ajouter les traductions dans [locales](src/locales/) pour les cinq langues.
4. Ajouter les services et leurs contrats, puis utiliser un composable ou un store pour les états réactifs. Le Studio fournit son contexte Vue/Pinia ; [main.ts](src/main.ts) crée uniquement celui du mode autonome. Ne pas monter une nouvelle application Vue dans `App.vue`.
5. Construire, publier et déclarer l'application dans le catalogue, puis vérifier le parcours dans le Studio authentifié.

Les composants visuels du Studio s'importent depuis `ai-components-lib/studio`, par exemple :

```vue
<script setup lang="ts">
import { Button } from 'ai-components-lib/studio';
import { useI18n } from 'vue-i18n';

const { t } = useI18n({ useScope: 'global' });
</script>

<template>
  <Button>{{ t('common.save') }}</Button>
</template>
```

`common.save` provient des traductions de la bibliothèque. Conserver l'import de `ai-components-lib/studio.css` dans le composant exposé : le Studio charge `App.vue` directement et n'exécute pas `main.ts`. Les styles de la bibliothèque incluent des règles globales ; vérifier leur coexistence avec l'hôte lors de l'intégration.

### Traductions

Comme les autres microfrontends, le template range ses textes dans `src/locales/<langue>/<nom>.json`. Ajouter chaque clé dans les cinq fichiers [frontTemplate.json](src/locales/fr/frontTemplate.json). Le nom du fichier devient l'espace de noms : `hello` se lit avec `t('frontTemplate.hello')`. Pour un nouveau front, renommer les cinq fichiers et adapter les clés utilisées dans les composants.

Dans un composant enfant, utiliser le même modèle que [HelloWorld.vue](src/components/HelloWorld.vue) :

```ts
import { useI18n } from 'vue-i18n';

const { t } = useI18n({ useScope: 'global' });
```

[i18n.ts](src/i18n.ts) charge les JSON et fusionne les messages de `ai-components-lib` via `ai-utils-lib`. `App.vue` fournit cette instance à ses descendants et suit `LanguageManager` sans modifier le contexte i18n du Studio. `main.ts` installe également le plugin pour le mode autonome. Les modifications de langue sont prises en compte sans rechargement ; le français est la langue de repli.

## ✨ Fonctionnalités

- Composant `./App` exposé par la fédération native Vite, utilisable par le chargeur catalogue du Studio.
- Styles et variables du design system Studio, avec prise en charge du thème de l'hôte.
- Langues `fr`, `en`, `es`, `it` et `pt`, synchronisées avec `LanguageManager` ; l'abonnement est retiré au démontage.
- Exemple de service HTTP authentifié, validé à l'entrée et testé sans appeler de serveur réel.

## 🏗️ Architecture

Le Hub résout l'application depuis le catalogue ; le Studio charge le remote ESM, puis rend `./App` dans son propre arbre Vue. Le contexte i18n du template est fourni aux descendants sans remplacer celui de l'hôte. L'entrée locale `main.ts` est distincte de ce chemin d'intégration.

Le service [workflowService.ts](src/services/workflowService.ts) illustre `GET /aiWorkflowManagement/V1/workflows/{workflowCode}/versions`. Il encode le code, utilise `axiosInstanceMS` et vérifie les champs `version` et `status` avant de retourner une projection typée. Les autres champs de la réponse ne sont pas exposés par cet exemple. Cette route requiert les droits de lecture du workflow ; consulter le contrat du service avant d'ajouter d'autres champs ou opérations.

Exemple d'utilisation dans un composable ou un store :

```ts
import { fetchWorkflowVersions } from './services/workflowService';

try {
  const versions = await fetchWorkflowVersions('MON_WORKFLOW');
  // Utiliser les versions dans l'état de la vue.
} catch (error) {
  // Présenter un état d'erreur adapté, sans exposer de données sensibles.
}
```

Pour un autre MS, utiliser son chemin et son contrat réels, valider les données externes, et gérer chargement, erreur et annulation selon le besoin. Ne pas supposer qu'un type TypeScript valide une réponse réseau. Les appels doivent partir d'une action explicite ou d'un flux métier choisi, pas de l'exemple fourni.

## ⚙️ Configuration et intégration Studio

### Appels microservices

Dans le Studio, la configuration et la session sont fournies par l'hôte. `axiosInstanceMS` lit l'origine de la gateway depuis `window.config.AI_GATEWAY_URL`, puis, si elle n'est pas définie, `window.sofiaConfig.apiGatewayUrl` ou `window.sofiaConfig.AI_MICROSERVICES_BASE_URL`. Elle doit être une origine HTTPS sans chemin ; HTTP est accepté uniquement entre pages et gateway loopback locales. Le client lit `sat` et ajoute sa valeur à l'en-tête `Authorization: Bearer`. Il peut tenter un renouvellement de session après un `401` si l'infrastructure d'authentification est disponible.

Pour un serveur de test local sur `http://127.0.0.1:8000`, une configuration publique peut être placée **avant** le module de `index.html` pour un essai local :

```html
<script>window.sofiaConfig = { apiGatewayUrl: 'http://127.0.0.1:8000' };</script>
```

Cette origine est un exemple, pas un serveur fourni par le template. Utiliser l'origine de la gateway autorisée par l'environnement cible ; ne pas contourner le contrôle d'origine du client avec une URL arbitraire.

### 🔐 Authentification en local

Sans container chargé de l'authentification, le microfrontend autonome ne connecte pas l'utilisateur et ne crée pas le cookie `sat`. Pour appeler un MS protégé en local :

1. Connectez-vous normalement au Studio de l'environnement autorisé et récupérez, dans les outils de développement du navigateur (`Application` / `Stockage` > `Cookies`), la valeur du cookie `sat` de cette session. C'est le jeton WSO2 pour la gateway, pas le JWT de session Hub ni un refresh token. Utilisez uniquement votre propre session et les droits prévus pour cet environnement.
2. Ouvrez http://127.0.0.1:3037/ dans le même navigateur. Dans `Application` / `Stockage` > `Cookies`, sélectionnez `http://127.0.0.1:3037` et créez un cookie nommé `sat` avec cette valeur. Utilisez le domaine de l'hôte local, le chemin `/` et `SameSite=Lax`. Il doit être lisible par JavaScript : ne cochez pas `HttpOnly`. Pour cette page HTTP loopback uniquement, ne cochez pas `Secure` si le navigateur refuse le cookie ; utilisez HTTPS et `Secure` hors de ce cas local.
3. Configurez la gateway comme indiqué ci-dessus, puis déclenchez une action qui appelle un service. L'exemple [workflowService.ts](src/services/workflowService.ts) ne s'exécute pas automatiquement : appelez `fetchWorkflowVersions` depuis votre composable ou votre store avec un code de workflow accessible.
4. Dans l'onglet `Réseau`, vérifiez le statut de la requête sans partager ses en-têtes. Supprimez le cookie local à la fin de vos tests.

**Alternative avec Bruno :** après une authentification RHBK réussie dans Bruno, récupérez la valeur du cookie `sat` dans ses cookies ou l'en-tête `Set-Cookie` de la réponse d'authentification, puis créez le cookie local comme à l'étape 2. La requête `Authenticate browser transaction` exige une transaction navigateur non consommée et son cookie `oidcState` correspondant ; consultez la procédure Bruno du projet Hub. Bruno et le navigateur ont des cookies distincts : l'authentification Bruno ne crée pas automatiquement le cookie local. Le champ `token` de cette réponse est le JWT Hub, pas le `sat`. Effacez les cookies et données sensibles de Bruno après utilisation.

Le cookie doit être visible depuis l'hôte de la page : `localhost` et `127.0.0.1` sont distincts, et les ports ne déterminent pas le domaine du cookie. Évitez les doublons `sat` sur des domaines ou chemins différents. Le jeton expire : en mode autonome, son renouvellement n'est pas garanti sans session et BFF d'authentification ; reconnectez-vous et remplacez-le si nécessaire.

Un `401` peut indiquer un jeton absent, expiré ou invalide ; un `403`, des droits insuffisants. Pour une erreur CORS ou réseau, vérifier l'accès à la gateway et sa configuration pour l'origine locale, notamment l'en-tête `Authorization`. Le cookie local ne remplace ni les permissions du MS ni la configuration CORS.

**Ne jamais** enregistrer le `sat` dans les sources, un fichier, une URL, les logs ou un ticket, ni le partager. N'utilisez pas la console JavaScript pour le manipuler et ne désactivez pas les protections du navigateur.

### Publication et catalogue

Le build actuel produit `dist/assets/optiflow.js`, expose `./App` et charge les chunks et `style.css` associés. Conserver la minification désactivée : avec cette combinaison Vite/fédération, elle laisse une référence CSS non résolue dans l'entrée. Le serveur statique doit servir tous les fichiers avec CORS, sur une origine autorisée par le Hub.

Faire publier le build et enregistrer dans le catalogue une entrée `staticSource: catalog` avec un `code` unique, un `renderingUrl` propre sous `/studio/`, `staticUrl` pointant vers le répertoire de publication, `staticVersion` et `staticEntry: optiflow`. Le Hub construit `<staticUrl><staticVersion>/assets/optiflow.js`. Exemple de chemin de rendu : `/studio/mon-outil/*`. Adapter noms et URL au projet et à l'environnement ; le template ne crée ni entrée, ni droits, ni publication.

La politique du catalogue est `latest` en local et INT, version frontend explicite et immuable en RCT et PROD. La route doit être autorisée, les assets effectivement disponibles et la session disposer des droits nécessaires. Le script de provisionnement local existant ne déclare pas automatiquement ce nouveau projet. Consulter le runbook du Hub pour le provisionnement, l'administration, les ETag et la politique de publication. Les workflows utilisant `linkedApp` ont un chemin de configuration distinct.

Vérifier ensuite la résolution catalogue, le chargement de `./App`, les fichiers CSS/chunks, le thème, la langue et les appels MS avec une session autorisée. La page autonome ou la fixture de test ne prouve pas cette intégration de bout en bout.

### CI et livraison

[.gitlab-ci.yml](.gitlab-ci.yml) reprend l'include Vue partagé et le déclenchement du projet Terraform utilisés par les fronts Studio existants. Avant la première pipeline du nouveau dépôt :

1. Vérifier l'accès du projet et de ses runners à l'include GitLab, au registre npm interne et au projet Terraform cible.
2. Vérifier que l'image du job utilise Node.js 24 et que l'installation à partir du lockfile fonctionne. Les commandes disponibles sont `npm run build`, `npm run build-only`, `npm run type-check`, `npm test` et `npm run test:unit`.
3. Contrôler dans la configuration GitLab fusionnée les commandes, les variables, les règles de branche, les contrôles qualité, les artefacts et les autorisations réellement exigés par le modèle partagé. Le template ne fournit pas de script de lint ni de rapport de couverture : les ajouter si ce modèle les exige.
4. Confirmer le chemin de publication complet, la version, les règles CORS et la correspondance avec `staticUrl`, `staticVersion` et `staticEntry` du catalogue avant tout déploiement. Le fichier CI seul ne crée pas d'entrée catalogue, de droits ou de stockage.

La configuration GitLab fusionnée, les secrets et la pipeline déployée ne sont pas vérifiables depuis ce dépôt seul ; aucune publication n'est effectuée par ces instructions.

## 🧪 Tests et qualité

```bash
npm test
npm run type-check
npm run build
```

Les tests Node utilisent la simulation de modules expérimentale de Node 24 et couvrent les statuts du DTO, les réponses invalides et les erreurs de transport. Pour un contrôle manuel du remote : lancer le serveur `dev` sur 3037, construire, lancer `preview` sur 3038, puis ouvrir http://127.0.0.1:3037/tests/remote-smoke.html. La page charge l'entrée construite dans un hôte Vue/Pinia/i18n minimal, vérifie le CSS, les cinq langues et l'isolation des traductions de l'hôte ; l'attribut `data-result` de `<html>` vaut `pass` en cas de succès. Elle ne remplace pas une recette dans le Studio.

## 📁 Structure

```text
src/App.vue                     Composant autonome et exposé au Studio
src/components/HelloWorld.vue   Exemple de composant traduit
src/main.ts                     Montage Vue/Pinia/i18n en local
src/i18n.ts                     Chargement et configuration des traductions
src/locales/<langue>/           Traductions JSON par langue
src/services/workflowService.ts Exemple de transport MS
tests/                          Tests du service et fixture de fédération
vite.config.ts                  Fédération, ports et build
.gitlab-ci.yml                  Include CI Vue et déclenchement Terraform
.editorconfig                   Conventions de base de l'éditeur
```

## 🤝 Contribution

Garder les services sans état réactif, typer et valider les contrats externes, utiliser les composants Studio et traduire les textes. Lancer les contrôles ci-dessus et vérifier la pipeline, les parcours et les droits dans l'environnement cible avant livraison.
