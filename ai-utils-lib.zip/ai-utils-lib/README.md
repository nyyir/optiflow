# ai-utils-lib

## Axios authentication behavior

The shared microservice axios instance, `axiosInstanceMS`, sends requests using the provider access token from cookie `sat`, without falling back to the application JWT. Test-as-user requests use the dedicated `axiosInstanceTestAsUser`. The legacy `axiosInstance`, `axiosInstanceBFF` and `axiosInstanceTestAsUserBFF` exports have been removed.

The instances use one session coordinator after a 401, without delegating refresh to a container event handler. It calls the same-origin `/api/auth/refreshToken` with the stable HttpOnly `hubSessionId`. The exact response is `{accessToken, providerAccessToken}`; the coordinator commits the native JWT and gateway `sat` cookie only if the captured session is still current. Provider refresh and ID tokens remain in the encrypted BFF vault, never in JavaScript or the application JWT.

Concurrent requests and module copies in one window share a refresh. Safe requests are replayed at most once; mutations require explicit `authReplaySafe: true`. Late 401 responses reuse renewed credentials. Definitive refresh 401/403 responses end the session, whereas network errors and temporary server failures do not clear client credentials. `Retry-After` is honored without automatic retry loops. Refresh has a 25-second HTTP deadline; the BFF may require reauthentication when it cannot confirm provider rotation safely.

Logout ends local state and clears `sat` immediately. The BFF revokes the captured server session without `Set-Cookie`, so delayed logout/refresh responses cannot erase a newer login's cookies. Errors stay local to the caller by default; global navigation requires an explicit option. Gateway calls use `axiosInstanceMS`. Every final request origin is checked after sanitization before a Bearer is attached.

Only RHBK is supported: password login, WSO2 token extraction and persistent refresh counters have been removed. BFF calls use `/api`; gateway calls require an explicit validated `window.config.AI_GATEWAY_URL` or `window.sofiaConfig.apiGatewayUrl`. HTTPS is mandatory except for an explicitly configured loopback gateway from a loopback HTTP browser. No environment-based gateway is guessed.

The microservice client also permits `POST /authorizations/check` at the HTTPS `window.config.AI_AUTHORIZATION_MS_URL`, even when that service uses a different gateway origin. Other paths on that origin remain blocked unless it is the configured gateway origin.

Consumers must use and rebuild against the updated library distribution; mixed old/new bundles do not provide the complete failure policy. The shared lock coordinates copies in one window, not separate tabs.

### Corrections After 0.0.55

The checked release branches are `0.0.56`, `0.0.57`, `0.0.57.1`, `0.0.58` and `0.0.59`. Releases 56, 57 and 58 are already ancestors of this branch. The missing functional changes from `c98b0bd` and test adjustment `2358d30` have been incorporated without restoring the old event-driven refresh. The other missing release commits only change version metadata; runtime and development dependency versions already match release 59.

- SAT requests use [interface-aware selection](src/utils/cookies.ts), before dispatch and again after refresh. Sofia never falls back to the ONE parent-domain SAT; ONE retains its parent-domain selection. Selection does not depend on the order of `document.cookie` values.
- Missing cookie-domain metadata fails closed for Sofia and ambiguous duplicates. A single cookie on a non-Sofia interface retains the historical fallback. Browser support for Cookie Store is therefore required to distinguish coexisting SATs reliably.
- Refresh preserves the selected SAT's domain and path instead of creating a host-only duplicate that ONE would not select. The coordinator remembers this write scope for logout cleanup. The native JWT and gateway token remain separate, and the session revision is checked again after asynchronous cookie metadata is read.
- Dedicated `testAsUserToken` cookies keep their generic domain selector and never use the SAT application filter. The 25-second deadline, shared refresh lock, safe replay and logout/new-login race protections remain in place.

Regression coverage lives in [cookie tests](src/utils/cookies.spec.ts), [client replay tests](src/api/createAxiosInstance.spec.ts), [microservice client](src/api/axiosInstance.spec.ts) and [refresh race tests](src/auth/sessionRefresh.spec.ts), alongside the existing authentication/session/base-URL tests.

Package versions are unchanged by this correction port. A local rebuilt distribution is a development snapshot, not a published release or lockfile update. Publish a new library version containing both these corrections and the RHBK changes before updating deployed consumers; installing the old published package with the same version label does not include this working tree.

## Getting started

To make it easy for you to get started with GitLab, here's a list of recommended next steps.

Already a pro? Just edit this README.md and make it your own. Want to make it easy? [Use the template at the bottom](#editing-this-readme)!

## Add your files

- [ ] [Create](https://docs.gitlab.com/ee/user/project/repository/web_editor.html#create-a-file) or [upload](https://docs.gitlab.com/ee/user/project/repository/web_editor.html#upload-a-file) files
- [ ] [Add files using the command line](https://docs.gitlab.com/ee/gitlab-basics/add-file.html#add-a-file-using-the-command-line) or push an existing Git repository with the following command:

```
cd existing_repo
git remote add origin https://scm.saas.cagip.group.gca/cacf/fronts/interne/modules-js/sofia/hub/ai-utils-lib.git
git branch -M main
git push -uf origin main
```

## Integrate with your tools

- [ ] [Set up project integrations](https://scm.saas.cagip.group.gca/cacf/fronts/interne/modules-js/sofia/hub/ai-utils-lib/-/settings/integrations)

## Collaborate with your team

- [ ] [Invite team members and collaborators](https://docs.gitlab.com/ee/user/project/members/)
- [ ] [Create a new merge request](https://docs.gitlab.com/ee/user/project/merge_requests/creating_merge_requests.html)
- [ ] [Automatically close issues from merge requests](https://docs.gitlab.com/ee/user/project/issues/managing_issues.html#closing-issues-automatically)
- [ ] [Enable merge request approvals](https://docs.gitlab.com/ee/user/project/merge_requests/approvals/)
- [ ] [Set auto-merge](https://docs.gitlab.com/ee/user/project/merge_requests/merge_when_pipeline_succeeds.html)

## Test and Deploy

Use the built-in continuous integration in GitLab.

- [ ] [Get started with GitLab CI/CD](https://docs.gitlab.com/ee/ci/quick_start/index.html)
- [ ] [Analyze your code for known vulnerabilities with Static Application Security Testing (SAST)](https://docs.gitlab.com/ee/user/application_security/sast/)
- [ ] [Deploy to Kubernetes, Amazon EC2, or Amazon ECS using Auto Deploy](https://docs.gitlab.com/ee/topics/autodevops/requirements.html)
- [ ] [Use pull-based deployments for improved Kubernetes management](https://docs.gitlab.com/ee/user/clusters/agent/)
- [ ] [Set up protected environments](https://docs.gitlab.com/ee/ci/environments/protected_environments.html)

---

# Editing this README

When you're ready to make this README your own, just edit this file and use the handy template below (or feel free to structure it however you want - this is just a starting point!). Thanks to [makeareadme.com](https://www.makeareadme.com/) for this template.

## Suggestions for a good README

Every project is different, so consider which of these sections apply to yours. The sections used in the template are suggestions for most open source projects. Also keep in mind that while a README can be too long and detailed, too long is better than too short. If you think your README is too long, consider utilizing another form of documentation rather than cutting out information.

## Name

Choose a self-explaining name for your project.

## Description

Let people know what your project can do specifically. Provide context and add a link to any reference visitors might be unfamiliar with. A list of Features or a Background subsection can also be added here. If there are alternatives to your project, this is a good place to list differentiating factors.

## Badges

On some READMEs, you may see small images that convey metadata, such as whether or not all the tests are passing for the project. You can use Shields to add some to your README. Many services also have instructions for adding a badge.

## Visuals

Depending on what you are making, it can be a good idea to include screenshots or even a video (you'll frequently see GIFs rather than actual videos). Tools like ttygif can help, but check out Asciinema for a more sophisticated method.

## Installation

Within a particular ecosystem, there may be a common way of installing things, such as using Yarn, NuGet, or Homebrew. However, consider the possibility that whoever is reading your README is a novice and would like more guidance. Listing specific steps helps remove ambiguity and gets people to using your project as quickly as possible. If it only runs in a specific context like a particular programming language version or operating system or has dependencies that have to be installed manually, also add a Requirements subsection.

## Usage

Use examples liberally, and show the expected output if you can. It's helpful to have inline the smallest example of usage that you can demonstrate, while providing links to more sophisticated examples if they are too long to reasonably include in the README.

## Support

Tell people where they can go to for help. It can be any combination of an issue tracker, a chat room, an email address, etc.

## Roadmap

If you have ideas for releases in the future, it is a good idea to list them in the README.

## Contributing

State if you are open to contributions and what your requirements are for accepting them.

For people who want to make changes to your project, it's helpful to have some documentation on how to get started. Perhaps there is a script that they should run or some environment variables that they need to set. Make these steps explicit. These instructions could also be useful to your future self.

You can also document commands to lint the code or run tests. These steps help to ensure high code quality and reduce the likelihood that the changes inadvertently break something. Having instructions for running tests is especially helpful if it requires external setup, such as starting a Selenium server for testing in a browser.

## Authors and acknowledgment

Show your appreciation to those who have contributed to the project.

## License

For open source projects, say how it is licensed.

## Project status

If you have run out of energy or time for your project, put a note at the top of the README saying that development has slowed down or stopped completely. Someone may choose to fork your project or volunteer to step in as a maintainer or owner, allowing your project to keep going. You can also make an explicit request for maintainers.
